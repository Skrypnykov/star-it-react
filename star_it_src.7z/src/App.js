import './App.css';
import Navtop from './Components/Navtop/Navtop';
import Slider from './Components/Carousel/Carousel';
import FormFeedback from './Components/Form/Feedback';


function App() {
  return (
    <div>
      <Navtop fixed="top"/>    
      <Slider /> 
      <FormFeedback />
    </div>
  );
}

export default App;
